# TODO List for Math-Aware Question Bank Django App

- [x] Edit math_project/settings.py: Add 'core' to INSTALLED_APPS, configure MEDIA_URL and MEDIA_ROOT, add MONGO_URI and MONGO_DB_NAME.
- [x] Create core/mongodb.py: Helper function get_db() to connect to MongoDB.
- [x] Create core/tasks.py: Function process_pdf() to run Nougat OCR, parse output, store questions in MongoDB.
- [x] Edit core/views.py: Add index, upload_pdf, get_random_question views.
- [x] Create core/urls.py: Routing for the views.
- [x] Edit math_project/urls.py: Include core.urls and serve media files in debug mode.
- [x] Create core/templates/core/index.html: Frontend with MathJax config and "Get Question" button.
